# -*- coding: utf-8 -*-

__author__ = 'sobolevn'


class UserExitException(KeyboardInterrupt):
    pass
